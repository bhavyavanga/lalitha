package com.capgemini.fms.service;

import java.util.Map;
import java.util.regex.Pattern;

import com.capgemini.fms.dao.FeedbackDAO;
import com.capgemini.fms.dao.IFeedbackDao;
import com.capgemini.fms.exception.FeedbackException;


public class FeedbackService implements IfeedbackService {
	IFeedbackDao dao=new FeedbackDAO();
	public Map<String, Integer> addFeddbackDetails(String name, int rating, String subject) {
		return dao.addFeddbackDetails(name, rating, subject);
	}

	public Map<String, Integer> getFeedbackReport() {
		// TODO Auto-generated method stub
		return null;
	}
	public boolean validateTeacherName(String teacherName) throws FeedbackException {
		boolean resultFlag = false;
		String nameRegEx = "[A-Z]{1}[a-z]{4,}";

		if (!Pattern.matches(nameRegEx, teacherName)) {
			try {
				throw new FeedbackException("first letter should be capital and length should be > 5");
			} catch (FeedbackException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			resultFlag = true;
		}
		return resultFlag;
	}

	public boolean validateSubjectName(String subjectName) throws FeedbackException {
		boolean resultFlag = false;
		String nameRegEx = "1.Math2.English";

		if (!Pattern.matches(nameRegEx, subjectName)) {
			try {
				throw new FeedbackException("please enter correct input");
			} catch (FeedbackException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			resultFlag = true;
		}
		return resultFlag;
	}
	public boolean validateRating(int Rating) throws FeedbackException {

		boolean RatingFlag = false;
		if (Rating>6) {
			throw new FeedbackException("feedback should not be 1 to 5");
		} else {
			RatingFlag = true;
		}
		return RatingFlag;

	}
}
