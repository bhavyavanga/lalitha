package com.capgemini.fms.service;

import java.util.Map;

import com.capgemini.fms.exception.FeedbackException;

public interface IfeedbackService {
	Map<String, Integer> addFeddbackDetails(String name,int rating,String subject);
	Map<String, Integer> getFeedbackReport();
	public boolean validateTeacherName(String teacherName) throws FeedbackException;
	public boolean validateSubjectName(String subjectName) throws FeedbackException;
	public boolean validateRating(int subjectName) throws FeedbackException;
}
