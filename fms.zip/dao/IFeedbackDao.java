package com.capgemini.fms.dao;

import java.util.Map;

public interface IFeedbackDao {

	Map<String, Integer> addFeddbackDetails(String name,int rating,String subject);
	Map<String, Integer> getFeedbackReport();
}
