package com.capgemini.fms.dao;

import java.util.HashMap;
import java.util.Map;

public class FeedbackDAO implements IFeedbackDao {

	Map<String, Integer> MathFeedbackMap=new HashMap<String, Integer>();
	Map<String, Integer> EnglishFeedbackMap=new HashMap<String, Integer>();
	Map<String, Integer> newFeedbackMap=new HashMap<String, Integer>();
	
	public Map<String, Integer> addFeddbackDetails(String name, int rating, String subject) {
		newFeedbackMap.clear();
		if(subject.equalsIgnoreCase("Math"))
		{
			MathFeedbackMap.put(name, rating);
			newFeedbackMap.putAll(MathFeedbackMap);;
		}
		else if(subject.equalsIgnoreCase("English"))
		{
			EnglishFeedbackMap.put(name, rating);
			newFeedbackMap.putAll(EnglishFeedbackMap);
		}
		return newFeedbackMap;
		
	}

	public Map<String, Integer> getFeedbackReport() {
		// TODO Auto-generated method stub
		return null;
	}

}
