package com.capgemini.fms.presentation;

import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Scanner;

import com.capgemini.fms.bean.Feedback;
import com.capgemini.fms.exception.FeedbackException;
import com.capgemini.fms.service.FeedbackService;
import com.capgemini.fms.service.IfeedbackService;

public class UI {

	public static void main(String[] args) {
		String continueChoice;
		boolean continueValue = false;

		Scanner scanner = null;
		do {
			System.out.println("*** welcome to feedback Application");
			System.out.println("1.Add Feedback");
			System.out.println("2.Print Feedback Report");
			System.out.println("3.Exit");
			IfeedbackService service = new FeedbackService();
			int choice = 0;
			boolean choiceFlag = false;

			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter input:");
				try {
					choice = scanner.nextInt();
					choiceFlag = true;
					switch (choice) {

					case 1:
						boolean TeacherNameFlag = false;
						String teacherName = "";
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Teacher name:");
							teacherName = scanner.nextLine();
							try {
								service.validateTeacherName(teacherName);
								TeacherNameFlag = true;
							} catch (FeedbackException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							} while (!TeacherNameFlag);
						boolean SubjectNameflag = false;
						String subjectName = "";
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter subject name:");
							subjectName = scanner.nextLine();
							try {
								service.validateTeacherName(teacherName);
								SubjectNameflag = true;
							} catch (FeedbackException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						} while (!SubjectNameflag);
						boolean Ratingflag = false;
						int Rating = 0;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Rating:");
							Rating = scanner.nextInt();
							try {
								service.validateRating(Rating);
								Ratingflag = true;
							} catch (FeedbackException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						} while (!Ratingflag);

						Feedback feedback= new Feedback(teacherName,Rating,subjectName);
						
						

						break;
					case 2:
						boolean NameFlag = false;
						String Name = "";
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Teacher name:");
							teacherName = scanner.nextLine();
							try {
								service.validateTeacherName(teacherName);
								TeacherNameFlag = true;
							} catch (FeedbackException e) {
								TeacherNameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!TeacherNameFlag);
						
						
						break;

					case 3:
						System.out.println("Thank u, visit again");
						System.exit(0);
						break;
					default:
						System.out.println("input should be 1,2,3,4 or 5");
						choiceFlag = false;
						break;

					}
				} catch (InputMismatchException exception) {
					choiceFlag = false;
					System.err.println("input should contain only digits");
				}
			} while (!choiceFlag);

			do {
				scanner = new Scanner(System.in);
				System.out.println("do you want to continue again [yes/no]");
				continueChoice = scanner.nextLine();
				if (continueChoice.equalsIgnoreCase("yes")) {
					continueValue = true;
					break;
				} else if (continueChoice.equalsIgnoreCase("no")) {
					System.out.println("thank you");
					continueValue = false;
					break;
				} else {
					System.out.println("enter yes or no");
					continueValue = false;
					continue;
				}
			} while (!continueValue);

		} while (continueValue);
		scanner.close();
	}

}
